// Assets/Scripts/Combat/DamageCalculator.cs

namespace ElementTD
{
    // 기본 데미지에 전투형 슬롯 효과 배율과 몬스터 원소 배율을 곱해서
    // 최종 데미지를 계산하는 역할만 담당한다.
    public static class DamageCalculator
    {
        public static float CalculateFinalDamage(float baseDamage, float combatEffectMultiplier, float monsterResistanceMultiplier)
        {
            return baseDamage * combatEffectMultiplier * monsterResistanceMultiplier;
        }
    }
}
