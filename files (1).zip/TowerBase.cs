// Assets/Scripts/Towers/TowerBase.cs

using System.Collections.Generic;
using UnityEngine;

namespace ElementTD
{
    // 타워의 배치와 현재 위치의 타일 원소 조회를 담당하고,
    // 원소 시너지 조회와 데미지 계산 결과를 이용해 공격을 수행한다.
    public class TowerBase : MonoBehaviour
    {
        [SerializeField]
        private TowerDataSO _towerData;

        [Tooltip("게임에 존재하는 모든 원소 데이터 에셋 목록이다. 지금 단계에서는 인스펙터에서 직접 채워 넣는다.")]
        [SerializeField]
        private List<ElementDataSO> _elementDataList;

        private ElementSynergyEvaluator _synergyEvaluator;

        private void Awake()
        {
            _synergyEvaluator = new ElementSynergyEvaluator(_elementDataList);
        }

        // 타워를 주어진 위치로 이동시켜 배치한다.
        public void PlaceAt(Vector2 position)
        {
            transform.position = position;
        }

        // 현재 서 있는 타일의 원소를 조회한다.
        // 타일을 찾지 못하면 무속성을 반환한다.
        public ElementType GetCurrentElement()
        {
            ElementTile currentTile = ElementTile.FindTileAt(transform.position);

            if (currentTile == null)
            {
                return ElementType.None;
            }

            return currentTile.Element;
        }

        // 대상 몬스터를 공격하고 최종 데미지를 계산해서 적용한다.
        public void Attack(MonsterBase target)
        {
            ElementType currentElement = GetCurrentElement();
            ElementEffectSO effect = _synergyEvaluator.GetEffect(currentElement, _towerData.Tier);

            float combatEffectMultiplier = 1f;

            if (effect is StatModifierEffectSO statModifierEffect && statModifierEffect.TargetStat == TargetStat.Damage)
            {
                combatEffectMultiplier = 1f + statModifierEffect.ModifierValue;
            }

            float monsterResistanceMultiplier = target.GetResistanceMultiplier(currentElement);

            float finalDamage = DamageCalculator.CalculateFinalDamage(_towerData.BaseDamage, combatEffectMultiplier, monsterResistanceMultiplier);

            Debug.Log(_towerData.TowerName + " 공격, 원소 " + currentElement + ", 최종 데미지 " + finalDamage);

            target.TakeDamage(finalDamage);
        }
    }
}
